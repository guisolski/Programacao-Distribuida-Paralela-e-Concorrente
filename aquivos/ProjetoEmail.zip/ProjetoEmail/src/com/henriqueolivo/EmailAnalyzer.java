package com.henriqueolivo;

import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Queue;

public class EmailAnalyzer {
    Grafo graph;
    //"/Users/henriqueolivoantonio/IdeaProjects/ProjetoEmail/amostra-enron-2016"
    String path = "/Users/henriqueolivoantonio/IdeaProjects/ProjetoEmail/amostra-enron-2016";

    public ArrayList catchUsersEmailsPath() {
        File database = new File(path);
        File[] usersList = database.listFiles();
        ArrayList<File> allEmails = new ArrayList<>();

        assert usersList != null;
        for (File i : usersList) {
            //Avoiding DS_Store
            if (!i.getName().equals(".DS_Store")) {
                try {
                    File[] catchEmails = new File(i + "/_sent_mail").listFiles();
                    assert catchEmails != null;
                    System.out.println("[CatchEmails] Searching for all " + i.getName() + " emails [" + catchEmails.length + "].");

                    //Insert in Array List all Emails
                    allEmails.addAll(Arrays.asList(catchEmails));

                } catch (NullPointerException err) {
                    System.err.println("[CatchEmails] " + i.getName() + " _sent_mail folder not finded or have zero emails sent");
                }
            }
        }

        return allEmails;
    }

    public ArrayList<MatrizIC> filteringEmails() throws IOException {
        ArrayList allEmailsPathNotFiltered = catchUsersEmailsPath();
        ArrayList<MatrizIC> matrixResult = new ArrayList<>();

        for (int path = 0; path < allEmailsPathNotFiltered.size(); path++) {
            FileReader file = new FileReader((File) allEmailsPathNotFiltered.get(path));
            BufferedReader buffer = new BufferedReader(file);
            String line, from = "";
            ArrayList<String> to = new ArrayList<>();
            int linesThatNeedToBeCounted = 15, currentLinesCounter = 1;
            boolean toMultipleLines = false;

            while ((line = buffer.readLine()) != null && linesThatNeedToBeCounted != currentLinesCounter) {

                //Catching all From Destination
                if (line.startsWith("From:")) {
                    String SplitFromLine = line.split(" ")[1];
                    //Filtering only @enrom.com
                    if (SplitFromLine.endsWith(".com")) {
                        from = SplitFromLine.toLowerCase();
                    }
                }

                //Catching all To Destination
                if (line.startsWith("To:")) {
                    toMultipleLines = true;
                    line = line.split(" ")[1]; //Remove "From:"
                }

                if (line.startsWith("Subject:")) {
                    toMultipleLines = false;
                }

                if (toMultipleLines) {
                    String[] lineTemp = line.split(", ");
                    for (String l : lineTemp) {
                        l = l.replaceAll("\\s+", ""); // \\s+ remove space
                        l = l.replaceAll(",", "");
                        to.add(l);
                    }
                }

                currentLinesCounter++;
            }

            //System.out.println("From: " + from + " To: " + to);
            MatrizIC matrixTemp = new MatrizIC(from, to);
            matrixResult.add(matrixTemp);
        }
        return matrixResult;
    }

    public void createGraph() throws IOException {
        ArrayList<MatrizIC> matrixResult = filteringEmails();
        LinkedHashSet<String> allEmails = new LinkedHashSet<>();
        ArrayList<MatrizIC> matrixResultWithoutRepetition = new ArrayList<>();

        // Filtering repetition
        for (int email = 0; email < matrixResult.size(); email++) {
            allEmails.add(matrixResult.get(email).from);
        }

        for (MatrizIC matriz : matrixResult) {
            allEmails.addAll(matriz.to);
        }

        // Creating Graph
        graph = new Grafo(allEmails.size());

        int countVertices = 0;

        // Adding vertices (from)
        for (String email : allEmails) {
            graph.seta_informacao(countVertices, email);
            countVertices++;
        }


        //Removing repetition in matrixResult
        for (String i : allEmails) {
            ArrayList<String> toTemp = new ArrayList<>();

            for (MatrizIC matriz : matrixResult) {
                if (matriz.from.equals(i)) {
                    toTemp.addAll(matriz.to);
                }
            }

            MatrizIC matrizTempo = new MatrizIC(i, toTemp);
            matrixResultWithoutRepetition.add(matrizTempo);
        }

        // Printing Matrix with From and all To
        /*for (MatrizIC matriz : matrixResultWithoutRepetition) {
            System.out.println("From: " + matriz.from + " To: " + matriz.to);
        }*/

        // Adding edges
        for (MatrizIC matriz : matrixResultWithoutRepetition) {
            String from = matriz.from;
            for (String to : matriz.to) {
                int countFrequency = 0;
                for (String email : matriz.to) {
                    if (email.equals(to)) {
                        countFrequency++;
                    }
                }

                int indexFrom = graph.index_email(from);
                graph.cria_adjacencia(indexFrom, to, countFrequency);
            }

        }

        graph.imprime_adjacencias();
    }

    public int numVertices() {
        return graph.num_vertices();
    }

    public int numEdges() {
        return graph.tam_adjacencias();
    }

    public void outputDegree(int quant) {
        graph.maior_grau_saida(quant);
    }

    public void inputDegree(int quant) { graph.maior_grau_entrada(quant); }

    public ArrayList depthSearch(String origem, String destino, ArrayList caminho) {
        return graph.busca_profundidade(origem, destino, caminho);
    }

    public ArrayList widthSearch(Queue fila, String destino, ArrayList visitados) {
        return graph.busca_largura(fila, destino, visitados);
    }

    public ArrayList distance(String email, int aresta, int contador) {
        return graph.distancia(email, aresta, contador);
    }

    public int worstDistance(String i, String j) {
        return graph.piorCaminho(i, j);
    }
}
