package com.henriqueolivo;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Mesparsa {
    ListaSE linhas[];
    int tam;
    double inf = Double.POSITIVE_INFINITY;

    public Mesparsa(int tam){
        this.tam = tam;
        linhas = new ListaSE[tam];
        for (int i = 0 ; i < tam ; i++){
            linhas[i] = new ListaSE();
        }
    }

    public void insere(int i, String j, int valor) {
        if (i <= tam){
            linhas[i].insere_ordenado(valor, j);
        }
    }

    public ArrayList adjacentes(int j){
        return linhas[j].adjacentes();
    }

    public void imprime(int j) {
        linhas[j].imprime();
    }

    public int tam_adjacentes() {
        int cont = 0;
        for (int i = 0; i < linhas.length ; i++) {
            cont += linhas[i].tam_adjacentes();
        }
        return cont;
    }

    public int tam_vertice_adjacentes(int i) {
        return linhas[i].tam_adjacentes();
    }

    public void remove(int i, String j){
        if (i <= tam){
            linhas[i].retira_coluna(j);
        }
    }

    public int busca_valor_result(String email) {
        int contador = 0;
        for (int i = 0 ; i < tam ; i++) {
            if (linhas[i].busca_valor_result(email) != (int) inf) {
                contador += linhas[i].busca_valor_result(email);
            }
        }
        return contador;
    }

    public int busca_peso(int x, String y) {
        return linhas[x].busca_valor_result(y);
    }

}
