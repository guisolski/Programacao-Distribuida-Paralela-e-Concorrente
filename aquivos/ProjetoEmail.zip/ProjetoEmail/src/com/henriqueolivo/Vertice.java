package com.henriqueolivo;

public class Vertice {
    String nome;

    public Vertice(String nome) {
        this.nome = nome;
    }

}


