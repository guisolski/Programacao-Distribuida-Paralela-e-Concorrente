package com.henriqueolivo;

public class Grau {
    String vertice;
    int grau;

    public Grau(String vertice, int grau) {
        this.vertice = vertice;
        this.grau = grau;
    }
}
