package com.henriqueolivo;

public class No {
    int dado;
    String coluna;
    No proximo = null;

    public No(int dado, String coluna) {
        this.coluna = coluna;
        this.dado = dado;
    }
}

