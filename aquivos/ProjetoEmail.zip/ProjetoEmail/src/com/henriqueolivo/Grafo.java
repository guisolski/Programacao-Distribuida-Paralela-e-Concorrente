package com.henriqueolivo;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Queue;

public class Grafo {
    Mesparsa matriz;
    Vertice vertices[];
    int tam;
    double inf = Double.POSITIVE_INFINITY;
    private static final boolean MEMBRO = true;
    private static final boolean NAOMEMBRO = false;

    public Grafo(int tam) {
        this.tam = tam;
        vertices = new Vertice[tam];

        for (int i = 0; i < tam; i++) {
            vertices[i] = new Vertice(null);
        }
        matriz = new Mesparsa(tam);
    }

    public void cria_adjacencia(int i, String j, int P) {
        matriz.insere(i, j, P);
    }

    public void remove_adjacencia(int i, String j) {
        matriz.remove(i, j);
    }

    public void seta_informacao(int i, String V) {
        if (i < tam) {
            vertices[i].nome = V;
        }
    }

    public ArrayList adjacentes(int j) {
        return matriz.adjacentes(j);
    }

    public int tam_adjacencias() {
        return matriz.tam_adjacentes();
    }

    public void maior_grau_saida(int quant) {
        Grau[] vertices_grau = new Grau[tam];
        int[] vertices_grau_tam = new int[tam];
        //Grau[] result = new Grau[tam];
        ArrayList<Grau> result = new ArrayList<>();

        for (int i = 0; i < tam; i++) {
            vertices_grau[i] = new Grau(vertices[i].nome, matriz.tam_vertice_adjacentes(i));
            vertices_grau_tam[i] = matriz.tam_vertice_adjacentes(i);
            //System.out.println(vertices[i].nome + " | " + vertices_grau_tam[i]);
        }
        Arrays.sort(vertices_grau_tam);

        for (int i = 0; i < tam; i++) {
            for (Grau grau : vertices_grau) {
                if (grau.grau == vertices_grau_tam[i]) {
                    //result[i] = grau;
                    result.add(grau);
                }
            }
        }
        for (int i = result.size() - 1; i >= result.size() - quant; i--) {
            System.out.print("[" + result.get(i).vertice + ", " + result.get(i).grau + "]");
        }
    }

    public void maior_grau_entrada(int quant) {
        Grau[] vertices_grau = new Grau[tam];
        int[] vertices_grau_tam = new int[tam];
        ArrayList<Grau> result = new ArrayList<>();

        for (int i = 0; i < tam; i++) {
            vertices_grau[i] = new Grau(vertices[i].nome, matriz.busca_valor_result(vertices[i].nome));
            vertices_grau_tam[i] = matriz.busca_valor_result(vertices[i].nome);
        }

        Arrays.sort(vertices_grau_tam);

        for (int i = 0; i < tam; i++) {
            for (Grau grau : vertices_grau) {
                if (grau.grau == vertices_grau_tam[i]) {
                    //result[i] = grau;
                    result.add(grau);
                }
            }
        }
        for (int i = result.size() - 1; i >= result.size() - quant; i--) {
            System.out.print("[" + result.get(i).vertice + ", " + result.get(i).grau + "]");
        }
    }

    public void imprime_adjacencias() {
        for (int i = 0; i < tam; i++) {
            System.out.print(vertices[i].nome + " | ");
            matriz.imprime(i);
        }
    }

    public int index_email(String email) {
        for (int i = 0; i < tam; i++) {
            if (vertices[i].nome.equals(email)) {
                return i;
            }
        }
        return -1;
    }

    public String email_index(int index) {
        return vertices[index].nome;
    }

    public int num_vertices() {
        return vertices.length;
    }

    public ArrayList busca_profundidade(String origem, String destino, ArrayList visitados) {
        ArrayList adjacentes = adjacentes(index_email(origem));
        ArrayList x;
        if (origem.equals(destino)) {
            return visitados;
        }
        if (!visitados.contains(origem)) {
            visitados.add(origem);
            for (int i = 0; i < adjacentes.size(); i++) {
                x = busca_profundidade((String) adjacentes.get(i), destino, visitados);
                if (x != null) {
                    return x;
                }
            }
        }
        return null;
    }

    public ArrayList busca_largura(Queue<String> fila, String destino, ArrayList visitados) {
        if (fila.isEmpty()) {
            return null;
        }
        String x = fila.remove();
        if (x.equals(destino)) {
            return visitados;
        }
        if (!visitados.contains(x)) {
            visitados.add(x);

            ArrayList<String> adjacentes = adjacentes(index_email(x));
            ArrayList<String> nao_visitados = new ArrayList<>();
            for (String email : adjacentes) {
                if (!visitados.contains(email) && !fila.contains(email)) {
                    nao_visitados.add(email);
                }
            }
            for (String email : nao_visitados) {
                fila.add(email);
            }
            return busca_largura(fila, destino, visitados);

        }
        return null;
    }

    public ArrayList<String> distancia(String email, int aresta, int contador) {
        ArrayList<String> lista = new ArrayList<>();
        ArrayList<String> adjacentes = adjacentes(index_email(email));
        if (aresta == contador + 1) {
            lista.addAll(adjacentes);
            return lista;
        }else {
            for (String i : adjacentes) {
                lista.addAll(distancia(i, aresta, contador + 1));
            }
        }
        return lista;
    }

    public int piorCaminho(String p, String q) {
        int s = index_email(p);
        int t = index_email(q);
        ArrayList<String> caminhoF = new ArrayList<>();
        int distancia[] = new int[tam];
        boolean perm[] = new boolean[tam];
        int caminho[] = new int[tam];
        int corrente, i, k = s, j = 0;
        int menordist, novadist, dc;

        for (i = 0; i < tam; i++) {
            perm[i] = NAOMEMBRO;
            distancia[i] = 0;
            caminho[i] = -1;
        }
        perm[s] = MEMBRO;
        distancia[s] = 0;
        corrente = s;
        while (corrente != t) {
            menordist = 0;
            dc = distancia[corrente];
            for (i = 0; i < tam; i++) {
                if (!perm[i]) {
                    novadist = dc +  matriz.busca_peso(corrente, email_index(i));//matriz[corrente][i];
                    if (novadist > distancia[i]) {
                        distancia[i] = novadist;
                        caminho[i] = corrente;
                    }
                    if (distancia[i] > menordist) {
                        menordist = distancia[i];
                        k = i;
                    }
                }
            }
            corrente = k;
            perm[corrente] = MEMBRO;
        }
        caminhoF.add(email_index(t));
        int caminho_f = t;
        //System.out.println(caminho_f);
        while (caminho_f != s) {
            caminho_f = caminho[caminho_f];
            caminhoF.add(email_index(caminho_f));
        }
        System.out.println("\nCaminho da distância: " + caminhoF);
        return distancia[t];
    }
}