package com.henriqueolivo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Main {

    public static void main(String[] args) throws IOException {
        EmailAnalyzer a1 = new EmailAnalyzer();

        a1.createGraph();
//        System.out.println("--------------------");
//        System.out.println("Número de Vertices: " + a1.numVertices());
//        System.out.println("Número de Arestas: " + a1.numEdges());
//        System.out.print("Quem mais enviou: "); a1.outputDegree(20);
//        System.out.print("\nQuem mais recebeu: "); a1.inputDegree(20);
//        System.out.print("\nBusca em profundidade: " + a1.depthSearch("vince.kaminski@enron.com", "john.lavorato@enron.com", new ArrayList<>()));
//        Queue<String> queue = new LinkedList<>();
//        queue.add("john.arnold@enron.com");
//        System.out.print("\nBusca em largura: " + a1.widthSearch(queue, "john.lavorato@enron.com", new ArrayList()));
//        System.out.println("Pior distância: " + a1.worstDistance("drew.fossum@enron.com", "martha.benner@enron.com"));
        System.out.println("Distância: " + a1.distance("drew.fossum@enron.com", 2, 0));
    } //beverly.beaty@enron.com
}
