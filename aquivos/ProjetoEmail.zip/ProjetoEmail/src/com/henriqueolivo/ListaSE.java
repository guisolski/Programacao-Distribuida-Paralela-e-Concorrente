package com.henriqueolivo;

import java.util.ArrayList;

public class ListaSE {

    No ultimo = null;
    No primeiro = null;
    double inf = Double.POSITIVE_INFINITY;

    public int vazia() {
        if (primeiro == null) {
            return 1;
        } else {
            return 0;
        }
    }

    public boolean busca_valor(String c) {
        double result = inf;
        No p = primeiro;
        while (p != null) {
            if (p.coluna.equals(c)) {
                result = p.dado;
                break;
            }
            p = p.proximo;
        }
        if (result != inf) {
            return true;
        }
        return false;

    }

    public int busca_valor_result(String c) {
        int result = 0;
        No p = primeiro;
        while (p != null) {
            if (p.coluna.equals(c)) {
                result = p.dado;
                break;
            }
            p = p.proximo;
        }
        return result;

    }

    public ArrayList adjacentes() {
        ArrayList<String> adjacentes = new ArrayList<>();
        No p = primeiro;
        while (p != null) {
            adjacentes.add(p.coluna);
            p = p.proximo;
        }
        return adjacentes;
    }

    public void retira_coluna(String c) {
        No p = primeiro;
        No ult = ultimo;
        No aux = null;
        if (p.coluna.equals(c)) {
            retira_primeiro();
        }
        if (ult.coluna.equals(c)) {
            retira_ultimo();
        }
        while (p != null) {
            if (p.coluna.equals(c)) {
                retira_depois(aux);
                break;
            }
            aux = p;
            p = p.proximo;
        }
    }

    public void insere_primeiro(int e, String c) {
        No novo = new No(e, c);
        if (vazia() == 1) {
            primeiro = novo;
            ultimo = novo;
        } else {
            novo.proximo = this.primeiro;
            primeiro = novo;
        }
    }

    public void imprime() {
        No p = primeiro;
        System.out.print("[");
        while (p != null) {
            System.out.print(" [" + p.coluna + "|" + p.dado + "] ");
            p = p.proximo;
        }
        System.out.print("]\n");
    }

    public No insere_depois(No p, int e, String c) {
        No novo = new No(e, c);
        novo.proximo = p.proximo;
        p.proximo = novo;
        return novo;
    }

    public void insere_ultimo(int e, String c) {
        if (vazia() == 1) {
            insere_primeiro(e, c);
        } else {
            ultimo = insere_depois(ultimo, e, c);
        }
    }

    public void insere_ordenado(int e, String c) {
        if (!busca_valor(c)) {
            if (vazia() == 1) { //vazio
                insere_primeiro(e, c);
            } else {
                if (e <= this.primeiro.dado) { //menor que o primeiro
                    insere_primeiro(e, c);
                } else {
                    if (e >= this.ultimo.dado) { //maior que o ultimo
                        insere_ultimo(e, c);
                    } else {  //intermediario
                        No p = this.primeiro;
                        while (p.proximo.dado < e) { //encontra o local onde ser colocado
                            p = p.proximo;
                        }
                        insere_depois(p, e, c);
                    }
                }

            }
        }
    }

    public void retira_primeiro() {
        if (vazia() == 0) {
            //System.out.println("Primeiro Retirado: " + primeiro.dado);
            primeiro = primeiro.proximo;
        }
    }

    public void retira_ultimo() {
        if (vazia() == 0 && primeiro != ultimo) {
            No p = primeiro.proximo;
            No ante = primeiro;
            while (p != ultimo) {
                ante = ante.proximo;
                p = p.proximo;
            }
            ultimo = ante;
            ante.proximo = null;
        } else {
            retira_primeiro();
        }
    }

    public void retira_depois(No No) {
        if (vazia() == 0 && primeiro != ultimo && No != ultimo) {
            No p = primeiro;
            while (p != ultimo) {
                if (No.dado == p.dado) {
                    if (ultimo != primeiro.proximo) {
                        p.proximo = p.proximo.proximo;
                    } else {
                        retira_ultimo();
                    }
                    break;
                }
                p = p.proximo;
            }
            //System.out.println(p.dado);
        }
    }

    public double ultimo_elemento() {
        return ultimo.dado;
    }

    public int tam_adjacentes() {
        No p = primeiro;
        int cont = 0;
        while (p != null) {
            cont++;
            p = p.proximo;
        }
        return cont;
    }
}