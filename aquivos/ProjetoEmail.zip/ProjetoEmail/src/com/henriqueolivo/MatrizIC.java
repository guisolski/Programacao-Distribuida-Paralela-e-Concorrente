package com.henriqueolivo;

import java.util.ArrayList;

public class MatrizIC {
    String from;
    ArrayList<String> to;

    public MatrizIC(String from, ArrayList<String> to) {
        this.from = from;
        this.to = to;
    }
}
